"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

Setup specification for distutils.

Please note this file has the version number replaced by
the make target, and is copied to setup.py.
"""
from setuptools import setup, find_packages

setup(
  name="sparkl_cli",
  description="SPARKL CLI utility",
  url="http://sparkl.com",
  author="Jacoby Thwaites",
  author_email="dev@sparkl.com",
  version="v1.3.5",
  #scripts=["sparkl"],
  entry_points = {
    "console_scripts": [
      "sparkl=sparkl_cli.main:main"
    ]
  },
  packages=find_packages(),
  package_data={
    "sparkl_cli": [
      "version.txt",
      "resources/*"]},
  license="MIT",
  install_requires=[
    "argparse",
    "psutil",
    "requests",
    "websocket_client",
    "elasticsearch",
    "certifi",
    "cookiejar"
  ])
