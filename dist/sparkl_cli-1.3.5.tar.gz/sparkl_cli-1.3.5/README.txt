SPARKL CLI
==========

[![Join the chat at
https://gitter.im/sparkl/cli](https://badges.gitter.im/sparkl/cli.svg)](https://gitter.im/sparkl/cli?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

Console CLI interface for managing running SPARKL nodes.

Get the latest from [releases](https://github.com/sparkl/cli/releases).

Build
-----

Choose python or python3 by setting the `PYTHON_VERSION` env var, then
use `make` as follows: 1. `export PYTHON_VERSION=3` (assuming you want
to use Python3, default is 2). 2. `make deps` to set up dependencies. 3.
`make rel` to create distribution in `dist` directory. 4. `make install`
to install. Use `sudo -H make install` if necessary. \#\# Run Use
`sparkl -h` to see help as follows:

    usage: sparkl_cli [-h] [-v] [-a ALIAS] [-s SESSION] [-t TIMEOUT]
                      {connect,close,session,login,logout,node,ls,source,render,object,put,rm,mkdir,undo,vars,call,listen,elastic,start,stop,active}
                      ...

    SPARKL command line utility.

    positional arguments:
      {connect,close,session,login,logout,node,ls,source,render,object,put,rm,mkdir,undo,vars,call,listen,elastic,start,stop,active}
        connect             create or show connections
        close               close connection
        session             show current session info
        login               login user or show current login
        logout              logout user
        node                show node info (administrator only)
        ls                  list content of folder or service
        source              view [and download] source configuration
        render              transform source configuration or local file into html
        object              get object JSON by name or id
        put                 upload XML source [or change] file
        rm                  remove object
        mkdir               create new folder
        undo                undo last change
        vars                set field variables
        call                invoke a transaction or individual operation
        listen              listen for events on any configuration object
        elastic             push JSON to Elasticsearch
        start               start a service
        stop                stop one or more services
        active              list active services

    optional arguments:
      -h, --help            show this help message and exit
      -v, --version         show program's version number and exit
      -a ALIAS, --alias ALIAS
                            optional alias for multiple connections
      -s SESSION, --session SESSION
                            optional session id, defaults to invoking pid
      -t TIMEOUT, --timeout TIMEOUT
                            request timeout in seconds, default 10

    Use 'sparkl_cli <cmd> -h' for subcommand help

Examples
--------

See our [wiki](https://github.com/sparkl/cli/wiki).

Uninstall
---------

-   To remove a global installation:
    `bash   sudo -H pip[3] uninstall sparkl_cli`
-   To remove a user installation: `pip[3] uninstall sparkl_cli`

