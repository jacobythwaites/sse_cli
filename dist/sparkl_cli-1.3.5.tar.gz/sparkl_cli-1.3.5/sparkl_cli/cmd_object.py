"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

Show object command implementation.
"""
from __future__ import print_function

from sparkl_cli.common import (
    get_current_folder,
    get_object,
    resolve)


def parse_args(subparser):
    """
    Adds module-specific subcommand arguments.
    """
    subparser.add_argument(
        "object",
        type=str,
        help="object id or path")


def command(args):
    """
    Retrieves the specified object by path or id.
    """
    path = resolve(
        get_current_folder(args), args.object)

    return get_object(args, path)
