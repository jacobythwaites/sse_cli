"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

Listen command implementation.
"""
from __future__ import print_function

import json

from sparkl_cli.common import (
    get_current_folder,
    get_websocket,
    resolve)

PATH_PREFIX = "sse_listen/websocket/"


def parse_args(subparser):
    """
    Adds module-specific subcommand arguments.
    """
    subparser.add_argument(
        "subject",
        type=str,
        nargs='?',
        default='/',
        help="path or id of configuration object. By default: /")


def listener(connected_ws):
    """
    Generator that yields the structured data received on the opened
    websocket.
    """
    try:
        for message in connected_ws:
            term = json.loads(message)
            yield term

    # Socket close or keyboard interrupt stop the generator.
    except BaseException:
        pass


def command(args):
    """
    Opens a websocket listening to the configuration subject, and
    returns a generator that yields the structured data received
    on the websocket.
    """
    path = resolve(
        get_current_folder(args), args.subject)

    ws_path = PATH_PREFIX + path
    ws = get_websocket(args, ws_path)
    generator = listener(ws)
    return generator
