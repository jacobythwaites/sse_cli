"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

List active services command implementation.

"""
from __future__ import print_function

from sparkl_cli.common import (
    get_object,
    sync_request)


def parse_args(subparser):
    """
    Adds module-specific subcommand arguments.
    """
    subparser.add_argument(
        "folder",
        type=str,
        nargs="?",
        default="/",
        help="folder or service id or path")


def list_services(args):
    """
    Lists the active services under the specified folder.
    """
    result = {
        "tag": "active",
        "attr": {
            "count": 0
        },
        "content": []
    }

    response = sync_request(
        args, "GET", "sse_svc/status/" + args.folder)

    term = response.json()
    if not term.get("tag") == "active":
        return term

    service_ids = term["attr"]["services"].split()
    result["attr"]["count"] = len(service_ids)

    for service_id in service_ids:
        service = get_object(args, service_id)
        if service:
            entry = {
                "tag": "service",
                "attr": {
                    "id": service["attr"]["id"],
                    "path": service["attr"]["path"]
                }
            }
            result["content"].append(entry)

    return result


def command(args):
    """
    Lists active services under the specified folder. If no folder
    is provided, lists active services under the user's root folder.
    """
    return list_services(args)
