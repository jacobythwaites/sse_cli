"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

Service start command implementation.
"""
from __future__ import print_function

from sparkl_cli.common import (
    get_current_folder,
    resolve,
    sync_request)


def parse_args(subparser):
    """
    Adds module-specific subcommand arguments.
    """
    subparser.add_argument(
        "service",
        type=str,
        help="service id or path")


def command(args):
    """
    Starts the specified service. The instance.spec property of a service
    controls instantiation, and may allow more than one instance of a
    service to exist at one time.
    """
    path = resolve(
        get_current_folder(args), args.service)

    response = sync_request(
        args, "POST", "sse_svc/start/" + path)

    return response.json()
