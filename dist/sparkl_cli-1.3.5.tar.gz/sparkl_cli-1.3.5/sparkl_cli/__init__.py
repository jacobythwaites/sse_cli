"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

SPARKL CLI Package file.

Invocation works as follows:

To invoke using package name (uses __main__.py):
  python -m sparkl_cli

To invoke using main module name (uses main.py directly):
  python -m sparkl_cli.main

If installed globally, invoke using:
  sparkl
"""
