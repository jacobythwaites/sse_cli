"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

Make directory command implementation.

This works by creating a change file that creates the
specified folder.
"""
from __future__ import print_function

import posixpath

from sparkl_cli.common import (
    get_current_folder,
    resolve,
    sync_request)


def parse_args(subparser):
    """
    Adds module-specific subcommand arguments.
    """
    subparser.add_argument(
        "path",
        type=str,
        help="path name of new folder")


def command(args):
    """
    Creates a new subfolder with the given path name. The
    parent folder must already exist.
    """
    path = resolve(
        get_current_folder(args), args.path)

    parent = posixpath.dirname(path)
    name = posixpath.basename(path)

    change = """
      <change>
        <folder name="{Name}"/>
      </change>
      """.format(
          Name=name)

    response = sync_request(
        args, "POST", "sse_cfg/change/" + parent,
        headers={
            "x-sparkl-transform": "gen_change",
            "Content-Type": "application/xml"},
        data=change)

    return response.json()
