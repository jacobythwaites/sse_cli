"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

Logout command implementation.
"""
from __future__ import print_function

from sparkl_cli.common import (
    sync_request)


def parse_args(_):
    """
    Adds module-specific subcommand arguments.
    """
    return


def command(args):
    """
    Logs out the currently logged-in user, if any.
    """
    response = sync_request(
        args, "POST", "sse_cfg/signout")

    return response.json()
