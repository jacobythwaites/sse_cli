"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.
Package main module delegates to main implementation module.
"""

from sparkl_cli import main

main.main()
