"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

Test login and logout
"""
import os
import pytest

from sparkl_cli.main import sparkl

TEST_SSE = os.environ.get("TEST_SSE")
TEST_USER = os.environ.get("TEST_USER")
TEST_PASS = os.environ.get("TEST_PASS")


class Tests():

    def test_login(self):
        sparkl(
            "connect",
            url=TEST_SSE)
        result = sparkl(
            "login",
            user=TEST_USER,
            password=TEST_PASS)
        assert result["tag"] == "user"
        assert result["attr"]["name"] == TEST_USER

    def test_logout(self):
        result = sparkl("logout")
        sparkl("close", all=True)
        assert result["tag"] == "user"
        assert result["attr"]["name"] == "unknown@unknowndomain"
