"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

Test module tests connect and close.
"""
import os
import pytest

from sparkl_cli.main import sparkl

TEST_SSE = os.environ.get("TEST_SSE")


class Tests():

    def test_close_all(self):
        result = sparkl(
            "close",
            all=True)
        assert result["tag"] == "closed"

    def test_connect_1(self):
        result = sparkl(
            "connect")
        assert result["tag"] == "connections"

    def test_connect_2(self):
        result = sparkl(
            "connect",
            url=TEST_SSE)
        assert result["tag"] == "pong"

    def test_close(self):
        result = sparkl("close")
        assert result["tag"] == "closed"
