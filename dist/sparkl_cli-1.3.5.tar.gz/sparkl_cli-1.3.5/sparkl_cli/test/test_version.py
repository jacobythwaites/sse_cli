"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

Test version.
"""
from sparkl_cli import main


class Tests():

    def test_version(self):
        assert main.get_version().startswith("sparkl_cli v")
