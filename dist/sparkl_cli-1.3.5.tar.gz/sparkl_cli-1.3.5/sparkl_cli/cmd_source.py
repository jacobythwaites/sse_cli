"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.
Get source command implementation.
"""
from __future__ import print_function
import tempfile
import subprocess


from sparkl_cli.common import get_source


def parse_args(subparser):
    """
    Adds module-specific subcommand arguments.
    """
    subparser.add_argument(
        "-o", "--output",
        help="write output to named local file")

    subparser.add_argument(
        "source",
        type=str,
        help="source path or id")


def show_source_as(args):
    """
    Retrieves the source code of a configuration either
    from the local file system or from a SPARKL instance.

    Creates a temp file to store the source code and
    optionally transforms its content into html.

    The temp file is deleted once the source code is returned.
    """

    # Create a temporary file.
    (_handle, temp_file) = tempfile.mkstemp()
    try:
        # Get content of tempfile from local file.
        get_source(args, temp_file)

        # Return content of tempfile.
        with open(temp_file, 'r') as data:
            return data.read()

    # Get rid of tempfile.
    finally:
        subprocess.call(['rm', temp_file])


def command(args):
    """
    Gets the SPARKL source XML specified by path. Use
    --output to have the XML output saved to a file.
    """

    # Handle -o flag
    if args.output:
        get_source(args, args.output)
        return None

    return show_source_as(args)
