"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

Session command implementation.
"""
from __future__ import print_function

from sparkl_cli.common import (
    get_working_dir)


def parse_args(_subparser):
    """
    Adds the module-specific subcommand arguments.
    """
    pass


def command(args):
    """
    Shows the session number, which can be used by another
    process invoking `sparkl -s SESSION`.
    """
    result = {
        "tag": "session",
        "attr": {
            "id": args.session,
            "dir": get_working_dir(args)
        }
    }

    return result
