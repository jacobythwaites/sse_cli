"""
Copyright (c) 2017 SPARKL Limited. All Rights Reserved.
Author <jacoby@sparkl.com> Jacoby Thwaites.

Upload source command implementation.
"""
from __future__ import print_function

from sparkl_cli.common import (
    get_current_folder,
    resolve,
    sync_request)


def parse_args(subparser):
    """
    Adds module-specific subcommand arguments.
    """
    subparser.add_argument(
        "file",
        type=str,
        help="file name containing XML to upload")

    subparser.add_argument(
        "folder",
        type=str,
        help="folder id or path, into which the change is placed")


def command(args):
    """
    Uploads SPARKL source or other valid XML change file.
    """
    with open(args.file, "rb") as upload_file:
        path = resolve(
            get_current_folder(args), args.folder)

        response = sync_request(
            args, "POST", "sse_cfg/change/" + path,
            headers={
                "x-sparkl-transform": "gen_change",
                "Content-Type": "application/xml"},
            data=upload_file)
        return response.json()
